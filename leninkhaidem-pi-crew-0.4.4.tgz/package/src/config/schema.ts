import { type Static, Type } from "typebox";
import { Value } from "typebox/value";
import {
	type AgentSlotConfig,
	DEFAULT_GLOBAL_SETTINGS,
	DEFAULT_TMUX_SETTINGS,
	type PiCrewConfig,
	defaultThinkingForAgent,
	isInheritedAgentSlot,
} from "../types.js";

const ThinkingLevelSchema = Type.Union([
	Type.Literal("off"),
	Type.Literal("minimal"),
	Type.Literal("low"),
	Type.Literal("medium"),
	Type.Literal("high"),
	Type.Literal("xhigh"),
]);

const ConcreteAgentSlotSchema = Type.Object({
	provider: Type.String({ minLength: 1 }),
	modelId: Type.String({ minLength: 1 }),
	thinking: Type.Optional(ThinkingLevelSchema),
});

const InheritedAgentSlotSchema = Type.Object({
	mode: Type.Literal("inherit"),
});

const AgentSlotSchema = Type.Union([ConcreteAgentSlotSchema, InheritedAgentSlotSchema]);

const ExecutionModeSchema = Type.Union([Type.Literal("session"), Type.Literal("subprocess")]);

const GlobalSettingsSchema = Type.Object({
	maxConcurrent: Type.Integer({ minimum: 1, maximum: 32 }),
	maxActive: Type.Integer({ minimum: 1, maximum: 256 }),
	maxParallelTasksPerCall: Type.Integer({ minimum: 1, maximum: 32 }),
	retentionDays: Type.Integer({ minimum: 0, maximum: 365 }),
	notifyOnCompletion: Type.Boolean(),
	agentScope: Type.Union([Type.Literal("user"), Type.Literal("project"), Type.Literal("both")]),
	confirmProjectAgents: Type.Boolean(),
	executionMode: Type.Optional(ExecutionModeSchema),
});

const TmuxSettingsSchema = Type.Object({
	mode: Type.Union([Type.Literal("off"), Type.Literal("window"), Type.Literal("external-session")]),
	killOnComplete: Type.Union([Type.Literal("off"), Type.Literal("after-grace")]),
	graceSeconds: Type.Integer({ minimum: 0, maximum: 3600 }),
});

const RawSchema = Type.Object({
	version: Type.Literal(1),
	agents: Type.Record(Type.String(), AgentSlotSchema),
	global: Type.Optional(GlobalSettingsSchema),
	tmux: Type.Optional(TmuxSettingsSchema),
});

export type ParseResult = { ok: true; value: PiCrewConfig } | { ok: false; errors: string[] };

export function parsePiCrewConfig(input: unknown): ParseResult {
	if (!Value.Check(RawSchema, input)) {
		const errors: string[] = [];
		for (const err of Value.Errors(RawSchema, input)) {
			const errPath = (err as { path?: string }).path ?? "";
			errors.push(`${errPath}: ${err.message}`);
		}
		return { ok: false, errors };
	}
	const parsed = input as Static<typeof RawSchema>;
	const agents: Record<string, AgentSlotConfig> = {};
	for (const [name, slot] of Object.entries(parsed.agents)) {
		if (isInheritedAgentSlot(slot)) {
			agents[name] = { ...slot };
			continue;
		}
		agents[name] = {
			...slot,
			thinking: slot.thinking ?? defaultThinkingForAgent(name),
		};
	}
	return {
		ok: true,
		value: {
			version: 1,
			agents,
			global: { ...DEFAULT_GLOBAL_SETTINGS, ...parsed.global },
			tmux: { ...DEFAULT_TMUX_SETTINGS, ...parsed.tmux },
		},
	};
}

export function emptyConfig(): PiCrewConfig {
	return {
		version: 1,
		agents: {},
		global: { ...DEFAULT_GLOBAL_SETTINGS },
		tmux: { ...DEFAULT_TMUX_SETTINGS },
	};
}
